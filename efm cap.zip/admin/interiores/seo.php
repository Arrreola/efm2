<div class="menu-content-area-b">
    <h1>SEO</h1>
</div>