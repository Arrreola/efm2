<div class="menu-content-area-c">
    <h1>MANUAL</h1>
</div>