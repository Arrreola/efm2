

<?php
if(isset($_POST['submit'])){
    $to = "jorge.arreola@v09.mx"; // this is your Email address
    $from = $_POST['email']; // this is the sender's Email address
    $nombre = $_POST['nombre'];
    $movil= $_POST['movil'];
    $mensaje = $nombre . " " . " wrote the following:" . "\n\n" . $_POST['message'];

    $headers = "From:" . $from;
    $headers2 = "From:" . $to;
    mail($to,$subject,$mensaje,$headers);
    echo "Mail Sent. Thank you " . $nombre . ", we will contact you shortly.";
    // You can also use header('Location: thank_you.php'); to redirect to another page.
    }
?>
